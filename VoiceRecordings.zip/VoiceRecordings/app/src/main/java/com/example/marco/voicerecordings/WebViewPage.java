package com.example.marco.voicerecordings;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;

public class WebViewPage extends AppCompatActivity {

    static final public String MYPREFS = "myprefs";
    static final public String PREF_URL = "restore_url";
    static final public String WEBPAGE_NOTHING = "about:blank";
    static final public String MY_WEBPAGE = "https://users.soe.ucsc.edu/~dustinadams/CMPS121/assignment3/www/index.html";
    static final public String TAG = "webview_example";
    public String AudioSavePathInDevice = null;
    MediaRecorder mediaRecorder;
    MediaPlayer mediaPlayer;
    int next;
    String size;
    WebView myWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view_page);

        myWebView = (WebView) findViewById(R.id.webView);

        myWebView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Binds the Javascript interface
        myWebView.addJavascriptInterface(new JavaScriptInterface(this), "Android");
        myWebView.loadUrl(MY_WEBPAGE);
    }

    //methods that will link the webview Javascript, to Java Android
    public class JavaScriptInterface{
        Context Con;

        JavaScriptInterface(Context c) {Con = c;}

        @JavascriptInterface
        public void record () {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try{
                        // Reading a file that might exist, else go to catch statement to create it
                        File f = new File(getFilesDir(), "file.ser");

                        //creating streams of files for getting info from files.
                        FileInputStream fi = new FileInputStream(f);
                        ObjectInputStream OIS = new ObjectInputStream(fi);

                        next = (int) OIS.readInt() + 1;
                        AudioSavePathInDevice = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + next + ".3gp";

                        fi.close();
                        OIS.close();

                        try {
                            FileOutputStream fo = new FileOutputStream(f);
                            ObjectOutputStream OOS = new ObjectOutputStream(fo);
                            OOS.writeInt(next);

                            OOS.close();
                            fo.close();
                        }
                        catch(IOException e){
                            e.printStackTrace();
                            Log.d(TAG,"Error in OutputStream");
                        }

                        MediaRecorderReady();

                        try {
                            // recording starts
                            mediaRecorder.prepare();
                            mediaRecorder.start();
                        } catch (IllegalStateException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }

                    catch (Exception e){
                        Log.e(TAG,"Recording error");
                        // create and write first number in file
                        try {
                            File f = new File(getFilesDir(), "file.ser");

                            FileOutputStream fo = new FileOutputStream(f);
                            ObjectOutputStream o = new ObjectOutputStream(fo);

                            o.writeInt(0);
                            o.close();
                            fo.close();
                        }
                        catch(IOException io){
                            io.printStackTrace();
                        }

                    }
                    Toast.makeText(WebViewPage.this, "Recording", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stop(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mediaRecorder.stop(); // recording stops
                    Toast.makeText(WebViewPage.this, "Stopping Recording", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void play() throws IllegalArgumentException, SecurityException, IllegalStateException{
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // object to play the audio
                    mediaPlayer = new MediaPlayer();
                    try {
                        mediaPlayer.setDataSource(AudioSavePathInDevice);
                        mediaPlayer.prepare();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }

                    mediaPlayer.start();// play the audio
                    // put some stuff here to play your recorded stuff
                    Toast.makeText(WebViewPage.this,"Playing Audio", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stoprec () {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //input code here to stop the playback audio recording
                    Toast.makeText(WebViewPage.this,"Stopping Recording", Toast.LENGTH_LONG).show();
                    if(mediaPlayer != null){
                        mediaPlayer.stop(); // stop audio
                        mediaPlayer.release(); // free up memory
                        MediaRecorderReady();
                    }
                }
            });
        }

        @JavascriptInterface
        public void exit(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // implement exit code pop activity off stack, go back to prev activity
                    Toast.makeText(WebViewPage.this, "Exiting Activity", Toast.LENGTH_LONG).show();

                    Intent i = new Intent(WebViewPage.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                }
            });
        }
    }

    // initialize recorder object
    public void MediaRecorderReady(){
        mediaRecorder=new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(AudioSavePathInDevice);
    }

}