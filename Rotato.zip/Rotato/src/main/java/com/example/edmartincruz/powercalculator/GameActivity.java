package com.example.edmartincruz.powercalculator;

import android.os.Bundle;
import android.app.Activity;
import android.view.Surface;

import com.unity3d.player.UnityPlayer;

public class GameActivity extends UnityPlayerActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UnityPlayer.UnitySendMessage("Main Camera", "OpenSpiralStage", "");
//        UnityPlayer.UnitySendMessage("Marco's Testing Bullet","initiateCWRotation","");
//   if (getWindowManager().getDefaultDisplay().getRotation() != Surface.ROTATION_0){
//            UnityPlayer.UnitySendMessage("Marco's Testing Bullet","initiateCWRotation","");
//        }
    }

}
